import './style.css';
import { days, typeLabels } from './data.js';

const mapUrl = address => `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(address)}`;
const weatherCodes = code => code === 0 ? ['☀️','晴朗'] : code < 4 ? ['⛅','多雲'] : code < 60 ? ['🌫️','霧或陰天'] : code < 80 ? ['🌧️','可能有雨'] : code < 90 ? ['🌦️','陣雨'] : ['⛈️','雷雨'];
const seasonal = {Salzburg:['12–21°C','早晚偏涼，帶薄外套'],Hallstatt:['10–19°C','湖區溫差大，備雨具'],Rabenstein:['11–20°C','長途駕駛留意晨霧'],Munich:['12–21°C','洋蔥式穿搭最實用'],Taipei:['24–31°C','返台炎熱，注意補水']};

const dayRoot = document.querySelector('#days');
function renderDays(filter='all') {
  dayRoot.innerHTML = days.map((d, i) => {
    const visibleStops = d.stops.filter(s => filter === 'all' || s[2] === filter);
    if (!visibleStops.length) return '';
    const [range, reminder] = seasonal[d.city] || ['10–21°C','帶一件防風外套'];
    return `<article class="day-block reveal" data-date="${d.date}">
      <div class="day-aside"><span>DAY</span><strong>${d.day}</strong><small>${d.weekday}<br>${d.date.slice(5).replace('-',' / ')}</small></div>
      <div class="day-main">
        <div class="day-top"><div><h3>${d.route}</h3><p>${d.note}</p></div><div class="weather" data-lat="${d.coords[0]}" data-lon="${d.coords[1]}" data-date="${d.date}"><span class="weather-icon">⛅</span><div><b class="weather-temp">${range}</b><small class="weather-note">${reminder}</small></div></div></div>
        <div class="travel-meta"><span>↗ ${d.drive}</span><span>⌖ ${d.city}</span></div>
        <div class="stop-grid">${visibleStops.map((s, j) => `<article class="stop-card ${j===0 && visibleStops.length>2?'featured':''}" data-type="${s[2]}">
          <div class="stop-image"><img src="${s[5]}" alt="${s[0]}" loading="lazy"><span>${typeLabels[s[2]]}</span></div>
          <div class="stop-body"><small>${s[1]}</small><h4>${s[0]}</h4><p>${s[4]}</p><div class="card-actions"><a href="${mapUrl(s[3])}" target="_blank" rel="noopener">Google Maps ↗</a><button class="mini-rate" data-place="${s[0]}" aria-label="推薦 ${s[0]}">☆ 推薦</button></div></div>
        </article>`).join('')}</div>
      </div>
    </article>`;
  }).join('');
  observeReveal();
  updateWeather();
}

document.querySelectorAll('.filter').forEach(btn => btn.addEventListener('click', () => {
  document.querySelectorAll('.filter').forEach(x => x.classList.remove('active')); btn.classList.add('active'); renderDays(btn.dataset.filter);
}));

async function updateWeather(){
  const now = new Date();
  document.querySelectorAll('.weather').forEach(async el => {
    const target = new Date(el.dataset.date+'T12:00:00');
    const diff = (target-now)/86400000;
    if (diff < -1 || diff > 16) return;
    try {
      const url=`https://api.open-meteo.com/v1/forecast?latitude=${el.dataset.lat}&longitude=${el.dataset.lon}&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max&timezone=auto&start_date=${el.dataset.date}&end_date=${el.dataset.date}`;
      const data=await fetch(url).then(r=>r.json());
      if(!data.daily?.time?.length) return;
      const [icon,label]=weatherCodes(data.daily.weather_code[0]);
      el.querySelector('.weather-icon').textContent=icon;
      el.querySelector('.weather-temp').textContent=`${Math.round(data.daily.temperature_2m_min[0])}–${Math.round(data.daily.temperature_2m_max[0])}°C`;
      el.querySelector('.weather-note').textContent=`${label} · 降雨 ${data.daily.precipitation_probability_max[0]}%`;
    } catch(e) { /* seasonal fallback remains visible */ }
  });
}

const commentsKey='alpine-trip-comments-v1';
let rating=5;
const starInput=document.querySelector('.star-input');
starInput.innerHTML=[1,2,3,4,5].map(n=>`<button type="button" data-rating="${n}" aria-label="${n} 顆星">★</button>`).join('');
function paintStars(){starInput.querySelectorAll('button').forEach((b,i)=>b.classList.toggle('selected',i<rating));}
starInput.addEventListener('click',e=>{const b=e.target.closest('button');if(b){rating=Number(b.dataset.rating);paintStars();}}); paintStars();
const getComments=()=>JSON.parse(localStorage.getItem(commentsKey)||'[]');
function renderComments(){
  const list=getComments();
  document.querySelector('#comments').innerHTML=list.length?list.map(c=>`<article class="comment"><div><strong>${escapeHtml(c.name)}</strong><span>${'★'.repeat(c.rating)}${'☆'.repeat(5-c.rating)}</span></div><p>${escapeHtml(c.message)}</p><small>${new Date(c.time).toLocaleDateString('zh-TW')}</small></article>`).join(''):'<div class="empty-comment">還沒有留言。成為第一個留下足跡的人吧。</div>';
  const avg=list.length?(list.reduce((a,c)=>a+c.rating,0)/list.length).toFixed(1):'—';
  document.querySelector('#rating-average').textContent=avg; document.querySelector('#rating-count').textContent=list.length?`${list.length} 則旅伴留言`:'還沒有留言';
}
function escapeHtml(s){const d=document.createElement('div');d.textContent=s;return d.innerHTML;}
document.querySelector('#comment-form').addEventListener('submit',e=>{e.preventDefault();const fd=new FormData(e.target);const list=getComments();list.unshift({name:fd.get('name'),message:fd.get('message'),rating,time:new Date().toISOString()});localStorage.setItem(commentsKey,JSON.stringify(list));e.target.reset();rating=5;paintStars();renderComments();toast('留言已收藏在這個瀏覽器');});
renderComments();

document.addEventListener('click',e=>{const b=e.target.closest('.mini-rate');if(b){const place=b.dataset.place;b.textContent=b.textContent.includes('已推薦')?'☆ 推薦':'★ 已推薦';b.classList.toggle('rated');toast(`${place}：${b.classList.contains('rated')?'已加入推薦':'已取消推薦'}`);}});
document.querySelector('#share-trip').addEventListener('click',async()=>{try{if(navigator.share)await navigator.share({title:document.title,text:'一起看看 2026 德奧公路旅行！',url:location.href});else{await navigator.clipboard.writeText(location.href);toast('旅程連結已複製');}}catch(e){}});
const menu=document.querySelector('.menu-btn');menu.addEventListener('click',()=>{const nav=document.querySelector('nav');nav.classList.toggle('open');menu.setAttribute('aria-expanded',nav.classList.contains('open'));});document.querySelectorAll('nav a').forEach(a=>a.addEventListener('click',()=>document.querySelector('nav').classList.remove('open')));
function toast(msg){const t=document.querySelector('.toast');t.textContent=msg;t.classList.add('show');setTimeout(()=>t.classList.remove('show'),2200);}
function observeReveal(){const ob=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting)e.target.classList.add('visible')}),{threshold:.08});document.querySelectorAll('.reveal').forEach(x=>ob.observe(x));}
renderDays(); observeReveal();
