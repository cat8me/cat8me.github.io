export const days = [
  { date:'2026-09-08', day:'01', weekday:'週二', route:'台北 → 杜拜 → 慕尼黑 → 薩爾斯堡', city:'Salzburg', coords:[47.8095,13.055], drive:'約 2.5 小時', note:'長途飛行後以入住、散步和一頓舒服的晚餐為主。', stops:[
    ['慕尼黑機場 SIXT','取車','transport','Munich Airport Center, 85356 München, Germany','抵達 13:15，完成租車手續後出發。','https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1200&q=82'],
    ['HOTEL max70','住宿','hotel','Maxglaner Hauptstraße 70, 5020 Salzburg, Austria','入住前聯絡飯店預留停車位。','https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&w=1200&q=82'],
    ['Augustiner Bräu Kloster Mülln','晚餐首選','food','Lindhofstraße 7, 5020 Salzburg, Austria','修道院啤酒館，適合用輕鬆的一餐開始旅程。','https://images.unsplash.com/photo-1515003197210-e0cd71810b5f?auto=format&fit=crop&w=1200&q=82'] ]},
  { date:'2026-09-09', day:'02', weekday:'週三', route:'薩爾斯堡 → Hallstatt', city:'Hallstatt', coords:[47.5622,13.6493], drive:'約 1.5 小時', note:'上午留給巴洛克古城，午後沿湖區前往 Hallstatt。', stops:[
    ['米拉貝爾花園','花園','nature','Mirabellplatz 3, 5020 Salzburg, Austria','早晨光線柔和，從花園望向城堡是經典取景角度。','https://images.unsplash.com/photo-1599661046827-dacde6976549?auto=format&fit=crop&w=1200&q=82'],
    ['薩爾斯堡老城','古城散步','culture','Getreidegasse, 5020 Salzburg, Austria','咖啡、購物與隨興散步，不安排過多定點。','https://images.unsplash.com/photo-1571729937049-8bdf338ddc24?auto=format&fit=crop&w=1200&q=82'],
    ['Seewirt Zauner','住宿','hotel','Marktplatz 51, 4830 Hallstatt, Austria','湖畔兩晚，抵達後慢慢熟悉村落。','https://images.unsplash.com/photo-1445019980597-93fa8acb246c?auto=format&fit=crop&w=1200&q=82'] ]},
  { date:'2026-09-10', day:'03', weekday:'週四', route:'Hallstatt 慢遊日', city:'Hallstatt', coords:[47.5622,13.6493], drive:'今日不趕路', note:'依天氣挑選 Skywalk、鹽礦或遊船，其餘時間交給湖畔。', stops:[
    ['Hallstatt 湖畔','湖畔散步','nature','Seestraße, 4830 Hallstatt, Austria','清晨與黃昏人潮較少，適合攝影。','https://images.unsplash.com/photo-1605540436563-5bca919ae766?auto=format&fit=crop&w=1200&q=86'],
    ['Hallstatt Skywalk','觀景台','nature','Salzbergstraße 21, 4830 Hallstatt, Austria','從高處俯瞰世界遺產村落與湖面。','https://images.unsplash.com/photo-1569777506593-c9af3c55b718?auto=format&fit=crop&w=1200&q=82'],
    ['Salzwelten Hallstatt','鹽礦','museum','Salzbergstraße 21, 4830 Hallstatt, Austria','若營運與時段合適再前往，行前確認最新公告。','https://images.unsplash.com/photo-1564399579883-451a5d44ec08?auto=format&fit=crop&w=1200&q=82'] ]},
  { date:'2026-09-11', day:'04', weekday:'週五', route:'Hallstatt → Burg Rabenstein', city:'Rabenstein', coords:[49.823,11.371], drive:'約 5 小時＋休息', note:'全程最長的移動日，保留兩次以上休息與彈性停靠。', stops:[
    ['Hallstatt 出發','晨間告別','nature','Hallstatt, Austria','早餐後再出發，不追求過早上路。','https://images.unsplash.com/photo-1500534623283-312aade485b7?auto=format&fit=crop&w=1200&q=82'],
    ['Burg Rabenstein','城堡區域','culture','Rabenstein 33, 95491 Ahorntal, Germany','抵達後入住附近住宿，今晚不再排固定景點。','https://images.unsplash.com/photo-1526392060635-9d6019884377?auto=format&fit=crop&w=1200&q=82'] ]},
  { date:'2026-09-12', day:'05', weekday:'週六', route:'Burg Rabenstein 生日日', city:'Rabenstein', coords:[49.823,11.371], drive:'放慢腳步', note:'今天的主角不是清單，是生日、陪伴與一頓值得記得的晚餐。', stops:[
    ['Franconian Switzerland','自然散步','nature','Fränkische Schweiz, Germany','依體力與天氣選擇短程步道或村莊散步。','https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?auto=format&fit=crop&w=1200&q=82'],
    ['生日慶祝','特別時刻','food','Burg Rabenstein, 95491 Ahorntal, Germany','預留充足時間，活動以住宿主人確認內容為準。','https://images.unsplash.com/photo-1519671482749-fd09be7ccebf?auto=format&fit=crop&w=1200&q=82'] ]},
  { date:'2026-09-13', day:'06', weekday:'週日', route:'Burg Rabenstein → 慕尼黑', city:'Munich', coords:[48.1351,11.582], drive:'約 2.5–3 小時', note:'回到慕尼黑，下午進入 BMW 的設計與汽車世界。', stops:[
    ['BMW Museum','博物館','museum','Am Olympiapark 2, 80809 München, Germany','出發前再次確認週日票券與最後入場時間。','https://images.unsplash.com/photo-1619767886558-efdc259cde1a?auto=format&fit=crop&w=1200&q=82'],
    ['BMW Welt','建築／展覽','museum','Am Olympiapark 1, 80809 München, Germany','與博物館相鄰，可依當天節奏彈性停留。','https://images.unsplash.com/photo-1607853554439-0069ec0f29b6?auto=format&fit=crop&w=1200&q=82'],
    ['Haus im Tal','住宿','hotel','Tal 24, 80331 München, Germany','市中心連住兩晚，適合步行探索。','https://images.unsplash.com/photo-1590490360182-c33d57733427?auto=format&fit=crop&w=1200&q=82'],
    ['Hofbräuhaus München','晚餐','food','Platzl 9, 80331 München, Germany','傳統巴伐利亞氛圍；熱門時段可能需要等候。','https://images.unsplash.com/photo-1515003197210-e0cd71810b5f?auto=format&fit=crop&w=1200&q=82'] ]},
  { date:'2026-09-14', day:'07', weekday:'週一', route:'慕尼黑自在散步', city:'Munich', coords:[48.1351,11.582], drive:'以步行為主', note:'購物、市集、咖啡與攝影，自由調整順序。', stops:[
    ['Marienplatz','城市地標','culture','Marienplatz, 80331 München, Germany','從老城核心開始，保留街拍時間。','https://images.unsplash.com/photo-1595867818082-083862f3d630?auto=format&fit=crop&w=1200&q=82'],
    ['Viktualienmarkt','市場','food','Viktualienmarkt 3, 80331 München, Germany','找一份當地小吃，也可順路補充旅途食材。','https://images.unsplash.com/photo-1488459716781-31db52582fe9?auto=format&fit=crop&w=1200&q=82'],
    ['RIMOWA Munich','購物','shop','Maximilianstraße 36, 80539 München, Germany','購物口袋：另找 Murnauers Bachblüten ORIGINAL Tropfen 20 ml。','https://images.unsplash.com/photo-1555529669-e69e7aa0ba9a?auto=format&fit=crop&w=1200&q=82'] ]},
  { date:'2026-09-15', day:'08', weekday:'週二', route:'慕尼黑 → 杜拜', city:'Munich', coords:[48.3537,11.775], drive:'機場移動', note:'早餐後退房、加油與還車，預留充足機場時間。', stops:[
    ['慕尼黑機場','還車／離境','transport','Nordallee 25, 85356 München, Germany','15:40 起飛；先完成 SIXT 還車再前往第一航廈。','https://images.unsplash.com/photo-1436491865332-7a61a109cc05?auto=format&fit=crop&w=1200&q=82'] ]},
  { date:'2026-09-16', day:'09', weekday:'週三', route:'杜拜 → 台北', city:'Taipei', coords:[25.0797,121.234], drive:'返家日', note:'03:45 自杜拜起飛，16:15 抵達桃園。', stops:[
    ['桃園國際機場 T2','旅程終點','transport','桃園國際機場第二航廈, Taiwan','帶著照片、味道與一路上的小故事回家。','https://images.unsplash.com/photo-1488646953014-85cb44e25828?auto=format&fit=crop&w=1200&q=82'] ]}
];

export const typeLabels = { nature:'自然', food:'餐飲', hotel:'住宿', museum:'博物館', culture:'人文', shop:'購物', transport:'交通' };
