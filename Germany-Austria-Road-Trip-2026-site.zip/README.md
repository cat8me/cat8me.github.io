# Germany & Austria Road Trip 2026

一頁式互動行程網站，內容整理自 Version 1.3。

## 快速更新

所有每日行程、景點、地址、照片與提醒集中在 `src/data.js`。修改完成後執行：

```bash
npm install
npm run dev
```

正式輸出：

```bash
npm run build
```

可部署檔案會產生在 `dist/`。

## 功能

- Alpine Editorial 響應式設計
- 9 日行程與類型篩選
- Google Maps 搜尋連結（以完整地址產生）
- 旅程前 16 天自動載入 Open-Meteo 預報；其他時間顯示季節參考
- 景點推薦按鈕、1–5 星留言與分享按鈕
- 已移除訂位代碼、票號、座位與旅客姓名等敏感資訊

## 留言同步

目前預覽版留言使用瀏覽器 `localStorage`，適合單機測試。若要讓不同朋友透過公開連結看到同一批留言，部署時需連接一個共用資料庫（例如 Supabase、Firebase 或 Cloudflare D1），再將 `src/main.js` 的 `getComments` 與表單提交改為 API 呼叫。

## 圖片

版面使用 Unsplash 遠端圖片。正式長期發布前可改成自有照片或固定授權素材，避免遠端資源日後變動。
